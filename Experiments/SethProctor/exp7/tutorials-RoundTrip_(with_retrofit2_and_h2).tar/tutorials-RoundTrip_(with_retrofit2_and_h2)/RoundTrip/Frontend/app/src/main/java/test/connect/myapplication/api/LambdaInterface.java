package test.connect.myapplication.api;

public interface LambdaInterface<T> {

    public void doSomething(T result);
}
