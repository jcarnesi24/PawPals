package cs309.godclass;

public interface IView {
    public void showText (String s);
    public void toastText (String s);
}
