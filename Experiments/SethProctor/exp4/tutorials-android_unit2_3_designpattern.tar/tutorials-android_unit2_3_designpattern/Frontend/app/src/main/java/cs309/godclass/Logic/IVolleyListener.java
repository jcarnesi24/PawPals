package cs309.godclass.Logic;

public interface IVolleyListener {
    public void onSuccess(String s);
    public void onError(String s);
}
