to run

just type
npm install

and then
node server.js
