package com.cs309.testing.View;

public interface TestingView {

    void updateUserInfoTextView(String info);
    void showProgressBar();
    void hideProgressBar();
    String getText();

}
