package myapp.Model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StringRepo extends JpaRepository<StringEntity, Long>{

}
