package com.example.sumon.androidvolley.utils;

public class Const {
	public static final String URL_JSON_OBJECT = "https://jsonplaceholder.typicode.com/users/1";
	public static final String URL_JSON_ARRAY = "https://jsonplaceholder.typicode.com/users";
	public static final String URL_STRING_REQ = "https://jsonplaceholder.typicode.com/users/1";
	public static final String URL_IMAGE = "http://sharding.org/outgoing/temp/testimg3.jpg";
}
